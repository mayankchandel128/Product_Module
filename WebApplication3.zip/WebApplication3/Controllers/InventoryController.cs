﻿using DAC;
using DAC.Imp;
using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ProductModule.Controllers
{
    //[RoutePrefix("api/Inventory")]
    public class InventoryController : ApiController
    {

        private string spAddUpdateInventory { get { return "sp_addupdateinventory"; } }
        private string spDeleteInventory { get { return "sp_deleteinventory"; } }  
        internal IInventoryRepo IIrepo;
        public InventoryController(IInventoryRepo _IIrepo)
        {
            this.IIrepo = _IIrepo;
        }
        public IHttpActionResult GetPageWiseList(int pageSize, int pageNo)
        {
            var o = IIrepo.GetPagedResult(pageNo, pageSize);
            return Json(o);
        }
        [HttpPost]
        public IHttpActionResult AddInventory(Product obj)
        {
            if (obj != null)
            {
                try
                {
                    var data = IIrepo.AddUpdateInventory(obj, spAddUpdateInventory);
                    return Json(data);
                }
                catch (Exception e)
                {
                    return Json("api/Inventory/AddInventory"+e);
                }
            }
            else
            {
                return Json("failed");
            }
        }
        [HttpPost]
        public IHttpActionResult UpdateInventory(Product obj)
        {
            if (obj != null)
            {
                try
                {
                    var response = IIrepo.AddUpdateInventory(obj, spAddUpdateInventory);
                    return Json(response);
                }
                catch (Exception e)
                {
                    return Json("api/Inventory/UpdateInventory"+e);
                }
            }
            else
            {
                return Json("Not valid parameters"); ;
            }
        }
        [HttpPost]
        public IHttpActionResult DeleteInventory(Product obj)
        {
            if (obj != null)
            {
                try
                {
                    var response = IIrepo.DeleteInventory(obj, spDeleteInventory);
                    return Json(response);
                }
                catch (Exception e)
                {
                    return Json("api/Inventory/DeleteInventory :" + e);
                }
            }
            else
            {
                return Json("Not valid parameters");
            }
        }
    }
}
